import React, { useState } from 'react'

const Login = () => {
    const [formData, setFormData] = useState({ email: '', password: '' })
    const [formError, setFormError] = useState({})
    const submitHandler = () => {
        const error = {}
        for (const property in formData) {
            if (formData[property] === '') {
                error[property] = `${property} is required`
                // ({property:`${property} is required`})
            }
            setFormError(error)
            //console.log(`${property}: ${object[property]}`);
        }

    }
    const onClickHandler = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value })
        setFormError({ ...formError, [e.target.name]: '' })
    }
    console.log('formError===>', formError)
    return (
        <div class="container">


            <label for="email"><b>Email</b></label><br />
            <input type="text" placeholder="Enter email" name="email" value={formData.email} onChange={onClickHandler} />
            <p style={{ color: "red" }}>{formError?.email}</p>


            <label for="password"><b>Password</b></label><br />
            <input type="password" placeholder="Enter Password" name="password" value={formData.password} onChange={onClickHandler} />
            <p style={{ color: "red" }}>{formError?.password}</p>


            <button type="submit" onClick={submitHandler}>Login</button>

        </div>
    )
}

export default Login