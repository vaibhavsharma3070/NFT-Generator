import Header from '../components/Header'
import Meta from '../components/Meta'
import React, { useState } from 'react'
import SignUp from '../components/SignUp'

const Home = () => {
  // page content
  const pageTitle = 'Home'
  const pageDescription = 'welcome to react bootstrap template'
  // const [formData, setFormData] = useState({ email: '', password: '', firstName: '', lastName: '' })
  // const [formError, setFormError] = useState({})
  // const submitHandler = () => {
  //   const error = {}
  //   for (const property in formData) {
  //     if (formData[property] === '') {
  //       error[property] = `${property} is required`
  //       // ({property:`${property} is required`})
  //     }
  //     setFormError(error)
  //     //console.log(`${property}: ${object[property]}`);
  //   }

  // }
  // const onClickHandler = (e) => {
  //   setFormData({ ...formData, [e.target.name]: e.target.value })
  //   setFormError({ ...formError, [e.target.name]: '' })
  // }
  // console.log('formError===>', formError)

  return (
    <div>
      <Meta title={pageTitle} />
      <Header head={pageTitle} description={pageDescription} />

      <SignUp />
      {/* <div class="container">

        <label for="firstName"><b>firstName</b></label><br />
        <input type="text" placeholder="Enter firstName" name="firstName" value={formData.firstName} onChange={onClickHandler} />
        <p style={{ color: "red" }}>{formError?.firstName}</p>

        <label for="lastName"><b>lastName</b></label><br />
        <input type="text" placeholder="Enter lastName" name="lastName" value={formData.lastName} onChange={onClickHandler} />
        <p style={{ color: "red" }}>{formError?.lastName}</p>

        <label for="email"><b>Email</b></label><br />
        <input type="text" placeholder="Enter email" name="email" value={formData.email} onChange={onClickHandler} />
        <p style={{ color: "red" }}>{formError?.email}</p>


        <label for="password"><b>Password</b></label><br />
        <input type="password" placeholder="Enter Password" name="password" value={formData.password} onChange={onClickHandler} />
        <p style={{ color: "red" }}>{formError?.password}</p>


        <button type="submit" onClick={submitHandler}>Signin</button>

      </div> */}

    </div>
  )
}

export default Home