import axios from "axios"



export const SignUpApi = data => axios.post(`http://192.168.0.79:3005/api/auth/signup`, data)
export const LoginApi = data => axios.post(`http://192.168.0.79:3005/api/auth/login`, data)
export const GenerateApi = data => axios.get(`http://192.168.0.79:3005/api/user/generate`)

